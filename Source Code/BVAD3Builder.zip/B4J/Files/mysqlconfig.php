<?php
const DB_HOST = '';
const DB_NAME = '';
const DB_USER = '';
const DB_PASS = '';
?>